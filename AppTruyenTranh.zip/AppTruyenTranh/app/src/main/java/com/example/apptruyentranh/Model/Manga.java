package com.example.apptruyentranh.Model;

public class Manga {
    private String img;

    public Manga(String img) {
        this.img = img;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }
}
